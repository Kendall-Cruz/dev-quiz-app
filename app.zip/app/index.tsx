import { useEffect } from 'react';
import { router } from 'expo-router';
import { View, Text } from 'react-native';
import { LoggStates, useSessionContext } from '@/context/SessionContext';

export default function IndexScreen() {

    const { isLogged } = useSessionContext();
    useEffect(() => {


        if (isLogged) {
            router.replace('/(tabs)/CategoriesScreen');
        } else {
            router.replace('/(auth)/Login');
        }
    }, []);

    return (
        <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
            <Text>Cargando...</Text>
        </View>
    );
}