import { Slot, Stack } from 'expo-router';
import 'react-native-reanimated';
import "../global.css"


export default function RootLayout() {
   return <Slot />;
}
