import { View, Text } from 'react-native'
import React from 'react'

const CategoriesScreen = () => {
  return (
    <View>
      <Text>CategoriesScreen</Text>
    </View>
  )
}

export default CategoriesScreen